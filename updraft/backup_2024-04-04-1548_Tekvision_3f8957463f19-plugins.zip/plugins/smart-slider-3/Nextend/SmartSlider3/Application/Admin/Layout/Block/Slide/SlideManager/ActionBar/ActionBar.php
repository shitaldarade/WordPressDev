<?php

namespace Nextend\SmartSlider3\Application\Admin\Layout\Block\Slide\SlideManager\ActionBar;

/**
 * @var BlockActionBar $this
 */
?>
<div class="n2_slide_manager__action_bar">
    <?php

    $this->displayBulkActions();

    ?>
</div>
